
  <div>
    <div>
      <ul>
        <li><a href="contact.php">CONTACT</a></li>
        <li><a href="nearby.php">NEARBY</a></li>
        <li><a href="map.php">MAP</a></li>
        <li><a href="transportation.php">TRANSPORTATION</a></li>
        <li><a href="index.php">EVENTS</a></li>
      </ul>
    </div>
    <!-- image source -->
    <!-- http://www.visitithaca.com/themes/custom/ithaca/i/logo/Visit-Ithaca_Logo.png -->
    <img id="ithacaIMG" alt="ithaca" src="images/ithaca.jpg">
  </div>
